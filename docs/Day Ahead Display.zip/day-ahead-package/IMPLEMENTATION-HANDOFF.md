# Day Ahead Display — Implementation Handoff

> A complete brief for the implementing LLM/engineer working **inside the
> `amcchord/email` repo**. Read top-to-bottom. The visual spec is the mockup
> bundle in this project (`Day Ahead Display.html` + `editorial.jsx` +
> `swiss.jsx` + `data.js` + `atoms.jsx` + `fonts.css`). This document explains
> what was designed and exactly how to render it on the 13.3″ panel using the
> Pillow e-ink engine you already ship.

---

## 0. TL;DR

Add a new **portrait, glanceable "Day Ahead" screen** for the **E1004 13.3″
Spectra-6 panel (1200×1600)**, rendered **server-side by the existing Pillow
e-ink engine** (`backend/services/eink/pillow/`), driven by **calendar + email
+ todos** (plus slow-changing **house state** you already have from Home
Assistant). It refreshes **once an hour**.

You are *not* building a new device protocol or a new BMP encoder — both
already exist and already support this panel:

- The wire variant `spectra6_1200x1600` (`bmp4-spectra6-1200x1600`, 960,118 B)
  is registered in `backend/services/terminal/variants.py`.
- `encode_spectra6(img, width=1200, height=1600, dither=False)` in
  `backend/services/terminal/bmp.py` already emits the correct BMP.
- The terminal endpoints (`backend/routers/terminal.py`) already route, cache
  by ETag, and honor a per-device refresh interval.

What you ARE building: **(1)** a `DayShape` data assembler, **(2)** a TRMNL
pixel-font loader, **(3)** two new portrait design modules
(`dayahead_editorial.py`, `dayahead_swiss.py`), and **(4)** a thin dispatch +
`content_type` so a device can be set to show it. Ship **one** direction; both
are finished in the mockup so the owner can pick.

The single most important constraint is unchanged from the 7.3″ dashboard:
**6 colors, no greys, no gradients, no anti-aliased small text.** Everything
below ~24px is a **TRMNL pixel font at its native bitmap size**; everything
larger is Source Serif 4 (Editorial) or Helvetica (Swiss).

---

## 1. Hardware target & cadence

| Attribute | Value |
|---|---|
| Panel | SeedStudio E1004, 13.3″ Spectra-6 |
| Resolution | **1200 × 1600, portrait** (native; rotation handled server-side) |
| Colors | Black, White, Red, Green, Blue, Yellow (indices 0–5) |
| Wire variant | `?variant=spectra6_1200x1600` → `bmp4-spectra6-1200x1600` |
| BMP | 960,118 bytes, 4 bpp indexed, 1600 rows × 600 B, no dither |
| PPI | ~150 (legible but coarse) |
| Refresh | **hourly**; ~20 s wall-clock per full refresh; panel-life budget ≥ ~15 min/refresh |

**Cadence wiring.** The owner wants hourly updates. Set the device's
`refresh_interval_sec = 3600`. `terminal.py::schedule` already clamps it to
`[30 s, 6 h]` and returns it as `next_checkin_sec`, so no schedule code
changes are needed — just the per-device setting (see
`backend/routers/terminal_admin.py`).

**ETag stability (important for hourly).** The image ETag is `sha1(bmp_body)`.
For the device to skip redundant ~960 KB fetches, the render must be
**deterministic within the hour**: bucket "now" down to the top of the hour
before drawing the masthead clock / "as of" stamp / agenda NOW-line, exactly
like `renderer.py::_bucketed_now` already does for the placeholder. Use the
existing `render_bucket_sec` (set/confirm `3600` for the day-ahead path) so two
check-ins in the same hour produce byte-identical BMPs.

---

## 2. The mockup bundle (visual spec)

Open `Day Ahead Display.html` (this project) to see four artboards — both
directions in a **busy weekday** and a **calm weekend** state. It is the
pixel-level reference; reproduce its type scale, palette, insets, and color
semantics in Pillow.

| File | Role |
|---|---|
| `Day Ahead Display.html` | Gallery: mounts each 1200×1600 panel in its own React root, scaled to fit. |
| `editorial.jsx` | **Direction A** — warm broadsheet. `window.EditorialPortrait`, `DA_E_PALETTE`. |
| `swiss.jsx` | **Direction B** — modular agenda grid. `window.SwissPortrait`, `SW_PALETTE`. |
| `atoms.jsx` | Shared `WeatherGlyph` / `Diamond` / `Dot` (hand-drawn from primitives). |
| `data.js` | The `DayShape` contract + two fixtures (`DAY_BUSY`, `DAY_CALM`). |
| `fonts.css` | TRMNL `@font-face` + the no-AA pixel class. |
| `fonts/trmnl/` | TRMNL12/16/21 Regular+Bold (woff2). TTFs for the server are in `uploads/trmnl-font-family/`. |

The JSX renders with `React.createElement` only (no JSX syntax) and is a
straight, line-for-line transcription target for Pillow `ImageDraw` calls.

---

## 3. Where this slots into the engine

You already have a clean layered Pillow renderer. The day-ahead path **parallels**
the HA dashboard path rather than reusing its HA-specific view layer (the
appliance registry / `ha_view.py` are about HVAC reconciliation and appliance
timezones — irrelevant here). Reuse everything that's domain-neutral.

```
backend/routers/terminal.py
  _render_for_device(...)                     # ADD a `day_ahead` content_type branch
        │
        ▼
backend/services/terminal/renderer.py
  render_day_ahead_bmp(variant, device, settings)   # NEW (mirror render_dashboard_bmp)
        │  ├─ assemble_day_shape(...)          # NEW data layer
        │  └─ render_day_ahead_image(...)      # NEW portrait dispatcher
        ▼
backend/services/eink/day_client.py           # NEW — builds DayShape from cal+mail+todos+house
backend/services/eink/pillow/day_ahead.py     # NEW — (design, palette, day) -> 1200×1600 PIL image
backend/services/eink/pillow/dayahead_editorial.py   # NEW — Direction A drawers
backend/services/eink/pillow/dayahead_swiss.py       # NEW — Direction B drawers
        │
        └─ reuse unchanged:
             pillow/fonts.py      (EXTEND: add TRMNL loaders)
             pillow/palette.py    (reuse E_PALETTE_SIX / SW_PALETTE_SIX)
             pillow/draw.py       (reuse text/rule/line primitives)
             terminal/bmp.py      (encode_spectra6 — unchanged)
```

### 3.1 Concrete edits

**`render.py`** hardcodes `CANVAS_SIZE = (800, 480)` and whitelists only
`{"editorial","swiss"}`. **Do not** widen that function — leave the HA path
alone. Instead add a sibling entry point:

```python
# backend/services/eink/pillow/day_ahead.py
from PIL import Image
from .palette import get_palette          # reuse the 6-colour palettes

DAY_CANVAS = (1200, 1600)                  # portrait

def render_day_ahead_image(design, palette, day_shape, *, tz_name):
    design = design if design in ("editorial", "swiss") else "editorial"
    P = get_palette(design, palette)       # six | bw
    img = Image.new("RGB", DAY_CANVAS, color=P.bg)
    if design == "swiss":
        from . import dayahead_swiss as d
    else:
        from . import dayahead_editorial as d
    d.render_dashboard(img, day_shape, P, tz_name=tz_name)
    return img
```

**`renderer.py`** — add, next to `render_dashboard_bmp`:

```python
async def render_day_ahead_bmp(variant, *, device, settings):
    day = await assemble_day_shape(settings, tz_name=settings.timezone or "UTC")
    design  = (device.content_config or {}).get("design", "editorial")
    palette = "bw" if variant.key == "bw" else "six"
    img = await asyncio.to_thread(
        render_day_ahead_image, design, palette, day, tz_name=settings.timezone or "UTC")
    if img.size != (variant.width, variant.height):
        img = img.resize((variant.width, variant.height), Image.NEAREST)
    # dither OFF — same rationale as the HA dashboard (FS dither shreds pixel fonts)
    body = encode_spectra6(img, width=variant.width, height=variant.height, dither=False)
    return body, '"img-' + hashlib.sha1(body).hexdigest()[:16] + '"'
```

**`terminal.py::_render_for_device`** — add one branch:

```python
if content_type == "day_ahead":
    try:
        return await render_day_ahead_bmp(variant, device=device, settings=settings)
    except Exception:
        logger.exception("day_ahead render failed; falling back to clock")
        return render_bmp(variant, device_name=device_name, tz_name=tz_name)
```

This design is **portrait-native**. Gate the device to the
`spectra6_1200x1600` variant. If some other panel requests `day_ahead`, the
`NEAREST` resize will letterbox/squash it — acceptable as a fallback, but the
intended target is the E1004.

---

## 4. The `DayShape` data contract

`assemble_day_shape(settings, *, tz_name)` returns this dict (mirrors
`data.js`; the renderer computes display strings itself in `tz_name`, so you
only need the raw values). **Never crash on missing data** — every block has an
empty state.

```ts
type DayShape = {
  tz: string;                      // IANA, from TerminalSettings.timezone
  now_utc: ISO;                    // bucketed to the hour (see §1)
  date: { weekday, monthDay, year, iso, dow3 };   // localized in tz

  weather: {                       // from the existing HA shape (§4.1)
    now: { temp:int, code:'sunny'|'clear'|'partly'|'cloudy'|'rain', label:string },
    hi:int, lo:int, sunrise?, sunset?,
    forecast: [ {dow, code, hi, lo} ]   // next 3 days; [] if unavailable
  };

  events: [ {                      // today, in tz, status != cancelled
    id, start:ISO, end:ISO, allDay:bool, title, loc,
    kind:'meeting'|'focus'|'personal'|'travel',   // classified (§4.2)
    people?:int                    // attendee count for meetings
  } ];

  mail: {
    needsReply: { count:int, top:[ {from, subj, age} ] },  // top 3 by recency
    awaiting:int,                  // sent, no reply yet
    unread:int
  };

  todos: { count:int, overdue:int, dueToday:[ {title, overdue:bool} ] };

  house: {                         // SLOW state only — must be valid for an hour
    temps: { outdoor, first, second, third, basement },
    people: [ {name, home:bool} ],
    advisory: string              // e.g. "Garage open"; "" when none
  };

  tomorrow: { first: { start, title, loc } | null };
};
```

### 4.1 Field sources (reuse existing code)

| Block | Source |
|---|---|
| `events` | `CalendarEvent` rows for the user's accounts, today in `tz`. Reuse the query shape in `backend/routers/calendar.py::list_calendar_events` (it already handles tz day-boundaries and all-day vs timed). Map `summary→title`, `location→loc`, `start_time/end_time→start/end`, `attendees→people`. |
| `mail.needsReply` | The same "Needs Reply" queue the Flow dashboard surfaces (`backend/routers/ai.py` / `emails.py`). `count` + top 3 `{from=sender display, subj=subject, age=fmt_rel_time(received_at)}`. |
| `mail.awaiting` | "Awaiting response" (sent, no reply) count — Flow already computes this. |
| `mail.unread` | Unread count for the primary account. |
| `todos` | `Todo` model: `dueToday` = due ≤ today & not done; `overdue` = due < today. |
| `weather`, `house` | Reuse `backend/services/eink/ha_client.py::fetch_and_shape(settings)` — it already returns `weather`, `temps`, `people`, garage/windows. For `house.advisory`, reuse the garage-open / open-windows logic from the HA shape. **3-day forecast:** the current HA shape may only carry *current* conditions; if so, add a small forecast read (HA `weather.get_forecasts` service or the daily forecast attribute) and fill `forecast`; otherwise return `[]` and the renderer hides the strip. |
| `tomorrow.first` | First non-cancelled event after end-of-today in `tz`. |

### 4.2 Event classification (`kind`)

```
meeting  : attendees > 1  OR has hangout_link / conferencing
personal : organizer_self AND (no attendees) AND not all-day   (lunch, errands)
focus    : title matches /focus|review|deep work|block|writing/i  OR a solo timed hold
travel   : title/location matches /flight|train|drive|commute|airport/i
default  : meeting if it has any attendee, else personal
```

Classification only drives the accent colour and the editorial deck copy; get
it approximately right and move on.

---

## 5. Hero rotation (`pick_day_hero`)

Both directions spotlight **one** thing. Reproduce this priority:

```python
def pick_day_hero(day, now_min):
    upcoming = sorted([e for e in day.events if e.end_min > now_min],
                      key=lambda e: e.start_min)
    # 1. an event happening right now
    for e in upcoming:
        if e.start_min <= now_min < e.end_min:
            return ("now", e)
    # 2. the next event today
    if upcoming:
        return ("next", upcoming[0])
    # 3. nothing left today -> calm state
    return ("calm", None)
```

- `now`  → Editorial kicker "HAPPENING NOW" (red); Swiss hero cell **inverts to
  solid blue**, agenda block for that event inverts to solid accent.
- `next` → Editorial "UP NEXT · IN 30M"; accent **red if ≤30 min away**, else
  blue. Swiss shows the giant time.
- `calm` → Editorial "THE QUIET EDITION" with a drop-cap "A quiet day ahead.";
  Swiss shows the **outlined `0`** + "Nothing scheduled." (outline =
  `WebkitTextStroke` in the mock → in Pillow, draw the glyph outline as a
  3 px ink stroke with a `bg`-filled interior; **do not** fake it with a drop
  shadow).

The calm state is the whole point of an hourly wall display: most hours it
should look **calm**, not like a wall of counters.

---

## 6. Colour semantics (information, not decoration)

Six colours; every coloured pixel must mean something.

| Colour | Device RGB | Meaning in Day Ahead |
|---|---|---|
| **Red** `#c8261b` → snaps to `(255,0,0)` | needs you · happening now · overdue (needs-reply count, NOW line, overdue task, ≤30-min lead) |
| **Blue** `#1d4d8a` → `(0,0,255)` | scheduled meetings / calendar blocks |
| **Green** `#1f6b3a` → `(0,255,0)` | presence (● home) · "free / clear / caught up" · personal time |
| **Yellow** `#e7b800` → `(255,255,0)` | soon · advisory · sun. **Fills/marks only — never small text.** Native panel yellow is the weakest value on white; keep it to the advisory diamond and the sun glyph, exactly as the mock does. |
| **Black** | all structural ink — type, rules, frames, weather glyphs |

**Device-native snapping.** Keep using the engine's existing accent hexes
(`palette.py` `E_PALETTE_SIX` / `SW_PALETTE_SIX`). With `dither=False`,
`encode_spectra6` snaps each pixel to the nearest of the 6 native colours, so
`#c8261b→red`, `#1d4d8a→blue`, `#1f6b3a→green`, `#e7b800→yellow`. Do **not**
introduce new hues; they'll snap unpredictably. In the **bw** palette every
accent collapses to ink (already handled by `get_palette(design, "bw")`), and
the only allowed branch is the Swiss inverted cell, which uses solid ink as the
fill — same single exception as the HA dashboard (`Palette.is_bw`).

### 6.1 Colour as information (Editorial v2)

The Editorial direction leans the palette harder, but every use is still a
fact, not decoration:

- **Temperatures: highs = RED, lows = BLUE.** Every hi/lo pair across the
  weather band and the 3-day strip is coloured this way. The *current* temp
  (and the outdoor-now temp in The House) is coloured by **comfort**:
  `≥72°→red`, `≤55°→blue`, else ink. `tempColor(P,t,kind)` in `editorial.jsx`
  is the rule — port it verbatim.
- **Event kind drives the timeline colour:** meeting=blue, personal=green,
  focus=ink, travel=gold. The event time *and* its diamond marker take the
  kind colour; the title/meta stay ink. (`KIND` map in `editorial.jsx`.)
- **The lead kicker is a solid colour TAB** (filled rect, paper text) in the
  hero accent — red when ≤30 min / now, blue otherwise, green in the calm
  edition. This is the single loudest colour on the page; there is exactly
  one per render.
- **Spot-colour rules.** The masthead top rule and the `SpotRule` pairs
  (under the masthead, in the colophon) are **red**; section kickers and their
  ◇ ornaments take their section's accent.

### 6.2 Extra hues via duotone halftone (the dithering the owner asked for)

Spectra-6 only prints 6 inks, but two inks interleaved on a dot grid read as a
**third colour** at 1.5 m, and ramping the dot *density* down a band reads as a
**gradient**. Editorial v2 puts this in two decorative fields (never under text):

- **Time-of-day sky behind the masthead** — the headline colour moment. A
  vertical **density ramp** (dense dots at the top fading to clear by the date
  line) whose hue tracks the hour, so the wall display visibly changes through
  the day:

  | Period (local hour) | Sky inks | Reads as |
  |---|---|---|
  | dawn 05–08 | yellow + red | warm sunrise |
  | morning 08–11 | blue | clear cool blue |
  | midday 11–15 | blue (denser) | deep blue |
  | afternoon 15–18 | yellow + red | warm gold |
  | dusk 18–21 | blue + red | violet sunset |
  | night 21–05 | blue (densest) | deep night |

  `SKY_PERIOD()` / `SKY_SPEC()` / `SkyGradient` in `editorial.jsx` are the spec:
  11 bands, dot pitch 6 px, top radius ~1.8–2.1 px ramping to 0. The 134 px bold
  serif weekday sits over the upper (denser) bands and still reads; keep the ramp
  light enough that it never fights the type (verify at the panel's real size).
- **Accent tint wash** = a *very* sparse dot grid of the hero accent behind the
  FactStrip cells (`dots(accent, cell=11, r=0.6)`), a faint printed highlight.

The **weather glyphs are pure black & white** (the owner's call): one ink
line-art symbol inside an ink ring, no colour fill. Weather carries colour
through the *temperatures* (highs red / lows blue), not the icon.

These are **ordered** patterns at fixed pixel positions — see §11.4 for how to
render them deterministically in Pillow (drawn dot grids, **not**
Floyd–Steinberg).

---

## 7. Fonts — add TRMNL to the loader

The owner chose **TRMNL** as the pixel face for this screen (very legible at
~150 PPI). It has three native sizes — **12, 16, 21** — Regular + Bold. Treat
them like the existing Cherry/Tamzen/Spleen bitmaps: **never request a
non-native size** (FreeType will scale a bitmap face and turn "M" into "N").

1. Copy the TTFs to `backend/services/eink/static/fonts/trmnl/`
   (`TRMNL12-Regular.ttf`, `TRMNL12-Bold.ttf`, `TRMNL16-*`, `TRMNL21-*`). The
   files are attached in this project under `uploads/trmnl-font-family/`. Add
   them to `scripts/fetch_eink_display_fonts.sh` so fresh installs seed them.

2. Extend `backend/services/eink/pillow/fonts.py`:

```python
_TRMNL = {
    (12, False): "trmnl/TRMNL12-Regular.ttf", (12, True): "trmnl/TRMNL12-Bold.ttf",
    (16, False): "trmnl/TRMNL16-Regular.ttf", (16, True): "trmnl/TRMNL16-Bold.ttf",
    (21, False): "trmnl/TRMNL21-Regular.ttf", (21, True): "trmnl/TRMNL21-Bold.ttf",
}
def pix_trmnl(size, *, bold=False):
    """TRMNL pixel font. size MUST be 12, 16 or 21 (native bitmap sizes)."""
    native = min((12, 16, 21), key=lambda s: abs(s - size))   # clamp to nearest native
    return _load(os.path.join(_FONTS_ROOT, _TRMNL[(native, bold)]), native)
```

3. In Pillow, pixel-font runs need no AA disabling (Pillow renders the bitmap
   1:1) **provided you draw at the native size and snap text x/y to integers**.
   Keep all rule widths and glyph baselines on whole pixels.

> Rule of thumb (unchanged from the 7.3″ brief): **< 24 px ⇒ TRMNL pixel
> font.** Headlines/numerics ⇒ Source Serif 4 (Editorial) / Inter-as-Helvetica
> (Swiss), where AA edges disappear at scale.

---

## 8. Direction A — Editorial (warm broadsheet)

Source: `editorial.jsx`. The **date is the masthead/identity** (no wordmark).
Outer frame 1200×1600, paper-white, padding **34 top / 46 sides / 28 bottom**.
Vertical flow, each block separated by ink rules:

```
┌──────────────────────────────────────────────┐
│ AS OF 8:00 AM            DAY AHEAD · NO. THU   │  pix16, hairline under
│            T H U R S D A Y                     │  serif 132/700, -0.035em, centered
│            JUNE 5  ◇  2026                     │  serif 40/600 + italic 36
│ ════════════════════════════════ (6px+2px)    │  DoubleHr
│ ☼ 61°  PARTLY CLOUDY │ FRI ☼ 78°60° │ SAT … │  weather strip (now + 3-day)
│ ◇ UP NEXT · IN 30M ─────────────────────────  │  Kicker (accent)
│ 8:30 │ Morning review                          │  serif time 64 + headline 58
│ AM·30m│ italic deck …                          │  italic deck 26
│ ▔▔▔ WHEN │ WHERE │ THEN ▔▔▔ (FactStrip)        │
│ ◇ THE DAY · 5 AHEAD ────────────────────────  │  timeline kicker
│ 8:30ᴬᴹ ◇ Morning review    DESK · 30M          │  per-event rows, hairline between
│ 11ᴬᴹ   ◆ Design standup    CONF ROOM B · 30M·5P│  (◆ accent = kind colour)
│ … (remaining events) …                         │
│ ─────────────────  spacer  ─────────────────   │
│ ◇ NEEDS A REPLY    │ ◇ THE HOUSE                │  two bottom rails (1fr | 1fr)
│ 3  4 AWAIT 28 UNRD │ 61° OUTSIDE NOW            │
│ MARISA CHEN    2d  │ 3F 72° 2F 71° 1F 70° BS 68°│
│ Re: contract …     │ ● ANDREW HOME  ○ SAM OUT   │
│ ════════════════════════════════ (DoubleHr)    │
│ TOMORROW · 9:00 DENTIST  "…fits, ahead."  ↻ 8AM │  colophon
└──────────────────────────────────────────────┘
```

### 8.1 Type scale (Source Serif 4 unless noted; `acc()` = palette accent)

| Element | Font / size |
|---|---|
| Weekday masthead | serif **134** / 700 / `-0.035em` (ink), over the time-of-day dither sky (§6.2) |
| Month-day / year | serif **40**/600 ; year **36** italic ; flanked by R/B ◆ gems |
| Weather **stamp** | Ø **104** ink ring + **B&W** line-glyph (no colour fill) |
| Weather now temp | serif **84**/700, **comfort-coloured** ; HI red / LO blue (TRMNL 16) ; forecast hi/lo TRMNL 21 (red/blue) |
| Lead **KickerTab** | TRMNL 21 bold, paper-on-accent solid tab + accent rule + accent ◆ |
| Lead time | serif **66**/700 (hero accent) ; AM·dur TRMNL 21 |
| Lead headline | serif **60**/700 `-0.02em`, `text-wrap: balance` ; deck **26** italic |
| FactStrip | key TRMNL 12 ; value serif **27**/700 ; sub TRMNL 12 ; faint accent halftone behind cells |
| Timeline time | serif **34**/700 **(kind colour)** ; AM/PM TRMNL 12 ; ◆ kind colour ; title serif **31**/600 ; meta TRMNL 16 |
| Needs-reply count | serif **60**/700 (red) ; sender TRMNL 21 bold ; subj **21** italic ; age = TRMNL 12 paper-on-red tab |
| House outdoor | serif **60**/700 **comfort-coloured** ; floor label TRMNL 16 ; floor temp serif **24**/600 |
| SpotRule | single 2 px **red** rule (under masthead + colophon) |
| Colophon | TRMNL 16 ; R/B/G ◆ gems centre |

### 8.2 Rules & ornaments
- **Rules are kept sparse and light** (the owner dialed them back): a single
  2 px **red** SpotRule under the masthead and in the colophon, a 2 px ink rule
  to open the FactStrip, and 2 px row dividers in the timeline. No heavy double
  rules; The House block carries none internally (whitespace separates). Keep
  every rule ≥ 2 px so it survives the raster (don't use 0.5/0.75).
- **KickerTab** (lead only): a filled accent rectangle with paper text, then an
  accent rule, then an accent ◆. Section kickers (THE DAY / NEEDS A REPLY / THE
  HOUSE) stay as ◆ + coloured text, *not* tabs — one tab per page.
- **Diamond** = a real rotated square (`Diamond` atom), never the `◆` glyph.
  Bullet/gem colour carries meaning (kind colour in the timeline; R/B/G gem row
  in the colophon as a printer's flourish).
- **Weather stamp** — see §8.4 + §11.4.
- **Drop cap** on the calm-state body only (serif ~96, **green**, float left).
- **Presence** dot: filled = home (green), hollow ring = away (ink).

### 8.4 Colour & halftone (Direction A)
Port `editorial.jsx`'s colour helpers exactly:
- `tempColor(P, t, kind)` — hi→red, lo→blue, now→comfort. Applied to every
  temperature in the weather band, forecast strip, and The House.
- `KIND = {meeting:blue, focus:ink, personal:green, travel:gold}` — timeline
  time + diamond.
- Hero accent: `now/≤30min → red`, else `blue`; calm → green.
- **Halftone fields** (`dots()`, `duo()`, `SkyGradient`): the time-of-day
  masthead sky and the faint FactStrip wash. Render them as **drawn dot grids**
  in Pillow (§11.4) — the only places colour mixes, and they never sit under
  body text. The weather stamp is **B&W** (no halftone).

### 8.3 Component → Pillow map
Each JSX component is a `_draw_*` function taking `(draw, img, box, day, P,
ctx)`. `Kicker`→ ◇ + text + horizontal rule to right edge. `FactStrip`→ top
thick rule, N equal cells split by 2 px verticals, bottom hairline.
`WeatherGlyph`→ B&W line-art inside an ink ring (§11.5). `TimelineRow`→ right-aligned time column (width 124,
diamond gutter (12) + flex title/meta. Lay out top-down with a running `y`
cursor; the "spacer" simply pins the two rails + colophon to the bottom.

---

## 9. Direction B — Swiss (modular agenda grid)

Source: `swiss.jsx`. Müller-Brockmann grid, full-bleed cells, ISO section
labels `NN / NAME · STATE`, Helvetica display numerics, a **true time-ruled
agenda** with a red **NOW** line, **inverted cells when hot**. Outer 1200×1600
with a 3 px ink frame; cells butt to edges, 14–18 px inset inside.

```
┌──────────────┬───────────────┬────────────────┐
│ 2026·06·05   │  DAY AHEAD     │ ●3 AHEAD  ↻08:00│  header: ink-on-ink date register
│ THURSDAY     │               │                 │  (bg=ink, fg=paper) | label | chips
├──────────────┴───────────────┼────────────────┤
│ 00 / UP NEXT · IN 30M         │ 01 / WEATHER    │  hero (1fr | 340px)
│ 8:30 AM                       │ ☼ 61°  HI74 LO58│  Helvetica 132, -0.05em
│ Morning review                │ FRI│SAT│SUN 3day│  title Helvetica 44
│ [DESK][30M]                   │                 │  bordered pixel chips
├───────────────────────────────┴────────────────┤
│ 02 / AGENDA · 5 AHEAD            8 AM — 8 PM     │  agenda label
│ 8A ──────── NOW 08:00 ════════════════ (red)    │  hour rules + red NOW line
│ 9A ──── ▌8:30am Morning review ─────            │  event blocks: 6px accent
│10A ────────────────────────────────────        │  left bar, white ring,
│11A ──── ▌11am Design standup ──────             │  title ellipsised
│ … blocks placed by start/end across 8a–8p …     │  GRID_H≈820, gutter≈92
├──────────────┬───────────────┬────────────────┤
│ 03 / INBOX   │ 04 / TASKS    │ 05 / HOUSE       │  bottom cells (1fr|1fr|1fr)
│ ▓3▓ (RED bg) │ 3  [1 OVERDUE]│ 64° OUT          │  INBOX inverts to red when >0
│ MARISA  2d   │ ◆ Send budget │ 3F72 2F71 1F70…  │
│ …            │ …             │ ●ANDREW ○SAM     │
├──────────────┴───────────────┴────────────────┤
│ SRC·MAIL+CAL  ▲3 NEED REPLY  TMRW 9:00 DENTIST  │  footer
└─────────────────────────────────────────────────┘
```

### 9.1 Type scale (Helvetica = Inter TTF you already ship)

| Element | Font / size |
|---|---|
| Date register | TRMNL 21 bold (iso) + TRMNL 16 (weekday), `fg = paper on ink` |
| Section labels | `NN` TRMNL 16 bold + `/ NAME · STATE` TRMNL 16 bold `0.14em` |
| Hero time | Helvetica **132**/700 `-0.05em` ; AM/PM TRMNL 21 ; title Helvetica **44**/700 |
| Calm outline `0` | Helvetica **168**/700, interior = paper, **3 px ink outline stroke** |
| Hero chips | TRMNL 16 bold in a 2 px border box |
| Weather temp | Helvetica **72**/700 ; forecast dow/temp TRMNL 16 |
| Agenda block | time TRMNL 21 bold (accent) ; title Helvetica **21–25**/700 (ellipsis) ; meta TRMNL 16 |
| Cell counts | Helvetica **76**/700 ; rows TRMNL 16 |
| Footer | TRMNL 16 |

### 9.2 Agenda geometry (reproduce exactly)
- Window **8:00 → 20:00** (`DAY_START=480`, `DAY_END=1200`), grid height
  **≈820 px**, left gutter **≈92 px** for hour labels (`8A,9A,…,8P`).
- `y(min) = clamp((min-480)/720 · GRID_H)`. Hour rules = 2 px ink at each hour.
- Event block: `top=y(start)`, `height=max(30, y(end)-y(start))`, **6 px accent
  left bar**, title ellipsised, drawn with a **2 px paper gap** around it so it
  doesn't merge with the hour rules (the mock uses a `box-shadow` ring → in
  Pillow draw a 2 px `bg`-coloured rectangle border, **not** a shadow).
- **NOW line**: 3 px red full-width at `y(now)` + `NOW HH:MM` label (red, TRMNL
  16) in the gutter. Only when `DAY_START ≤ now ≤ DAY_END`.
- Empty agenda (calm): ruled grid + centred `NOTHING SCHEDULED TODAY` (TRMNL 21).

### 9.3 Inverted cells (the across-the-room signal)
- Hero cell → solid **blue**, paper text, when the hero is `now`.
- Agenda block → solid accent fill when that event is happening now.
- `03 / INBOX` cell → solid **red**, paper text, when `needsReply.count > 0`.
  In **bw** these become solid **ink** (the one allowed `is_bw` branch).

---

## 10. Rendering pipeline (what actually ships)

1. `assemble_day_shape(settings)` → `DayShape` (hour-bucketed `now`).
2. `render_day_ahead_image("editorial"|"swiss", "six", day, tz)` → 1200×1600
   RGB `Image`.
3. `encode_spectra6(img, 1200, 1600, dither=False)` → 960,118 B BMP +
   `sha1` ETag.
4. `terminal.py` serves it; the firmware diffs the ETag and fetches only on
   change. Hourly cadence via `refresh_interval_sec = 3600`.

**Floyd–Steinberg stays OFF; colour comes from *drawn* ordered dither.**
`encode_spectra6(..., dither=False)` snap-to-nearest keeps every TRMNL glyph and
hairline byte-exact (FS would shuffle the on/off pixels of the bitmap glyphs and
shred them). The extra hues the owner wants (orange suns, blue skies, accent
washes) are **not** produced by the encoder — they are **painted directly** as
two-ink dot grids at fixed pixel positions (§11.4), which is itself an ordered
dither and survives `dither=False` untouched because every pixel is already a
native palette colour. Deterministic, byte-stable within the hour, and no
error-diffusion anywhere near the type.

---

## 11. E-ink fidelity rules (audit before shipping)

These mirror the 7.3″ HANDOFF §9.4 — re-verify for the bigger canvas:

1. **No grey, no gradient, no `opacity<1`, no shadow, no blur.** The mock uses a
   couple of conveniences for browser fidelity that must become solids in
   Pillow: the Swiss cell divider `opacity:0.5` → a solid 2 px ink rule; the
   agenda block `box-shadow` ring → a 2 px `bg` border; the `0` outline
   (`WebkitTextStroke`) → an actually-stroked glyph.
2. **Rule widths ≥ 2 px.** Round any sub-pixel rule up. At 1200 px native a
   1 px hairline is real but fragile; 2 px reads cleanly across the room.
3. **Pixel fonts at native size only** (12/16/21), x/y snapped to integers.
4. **Decorative colour fields = drawn dot grids (halftone), never under body
   text.** The two places colour mixes are the **time-of-day masthead sky** and
   the faint **FactStrip wash**. Implement each as an explicit loop placing
   native-ink dots on a fixed grid:
   - *masthead sky*: 11 horizontal bands top→baseline; per band place a dot of
     the period's ink(s) on a 6 px pitch with the dot radius ramping from
     ~1.8–2.1 px (top) to 0 (cleared by the date line). Two-ink periods
     (dawn/afternoon/dusk) alternate the two inks on the offset grid (`duo`).
   - *accent wash*: the hero accent, one dot every ~11 px (very sparse) behind
     the FactStrip cells only.
   Draw these **before** the ink text on top, clip them to their region, and
   keep the dot pitch an integer so the pattern is identical every render
   (stable ETag). Because the dots are already palette colours, `dither=False`
   passes them through verbatim — the whole trick for >6 perceived colours on a
   6-ink panel without touching the type.
5. **Weather glyphs are hand-drawn black & white** from primitives (circle +
   rays for sun, stroked cloud, short strokes for rain) inside an ink ring — see
   `atoms.jsx::WeatherGlyph` + `WeatherStamp`. No colour fill on the icon. Do
   **not** use an icon font (it aliases) or the Weather-Icons TTF here.
6. **Readable at distance.** This is a wall display: the big serif/Helvetica
   layer (date, hero time, headline, counts) is the glance layer; the TRMNL
   layer is the up-close detail layer. Don't shrink the glance layer to fit
   more — drop content instead.

---

## 12. Empty states & staleness

| Situation | Behaviour |
|---|---|
| No events left today | Calm hero (`A quiet day ahead.` / outlined `0`); Agenda shows `NOTHING SCHEDULED TODAY`; `THE DAY · 0 AHEAD`. |
| `needsReply.count == 0` | Editorial rail shows `0 · INBOX CLEAR · "No one is waiting on you."` (green); Swiss `03/INBOX` not inverted, green `CLEAR`. |
| No todos due | `NONE DUE / ALL CAUGHT UP` (green). |
| `weather.forecast == []` | Hide the 3-day strip; keep the now-temp. |
| `house`/HA unreachable | Omit the house block cleanly (don't leave a dangling kicker). Keep last-good weather if you cache it. |
| Calendar/email backend error | Render whatever blocks you have; **never** 5xx the device — `_render_for_device` already falls back to the clock on exception. |
| Stale data | If the assembler served cached data older than the refresh interval, draw a small `↯ STALE Nm` chip in the colophon/footer (reuse the HA dashboard's staleness convention). Silent staleness is worse than a visibly-old number. |

---

## 13. Checklist

**Add**
- [ ] `static/fonts/trmnl/TRMNL{12,16,21}-{Regular,Bold}.ttf` (+ seed script)
- [ ] `pillow/fonts.py::pix_trmnl(size, bold)`
- [ ] `eink/day_client.py::assemble_day_shape(settings, tz_name) -> DayShape`
- [ ] `pillow/day_ahead.py::render_day_ahead_image(design, palette, day, tz)`
- [ ] `pillow/dayahead_editorial.py::render_dashboard(img, day, P, tz_name)`
- [ ] `pillow/dayahead_swiss.py::render_dashboard(img, day, P, tz_name)`
- [ ] `terminal/renderer.py::render_day_ahead_bmp(...)`
- [ ] `pick_day_hero(...)` (shared helper)

**Edit**
- [ ] `routers/terminal.py::_render_for_device` — add `day_ahead` branch
- [ ] device admin (`terminal_admin.py`) — allow `content_type="day_ahead"`,
      `content_config.design ∈ {editorial,swiss}`, and set
      `refresh_interval_sec=3600` + `render_bucket=3600` for the day-ahead path
- [ ] `scripts/fetch_eink_display_fonts.sh` — fetch TRMNL TTFs

**Reuse unchanged**
- `terminal/bmp.py` (`encode_spectra6`), `terminal/variants.py`
  (`spectra6_1200x1600`), `pillow/palette.py`, `pillow/draw.py`,
  `eink/ha_client.py` (for weather + house only).

**Verify (conformance)**
- [ ] `/terminal/{code}/schedule.json?variant=spectra6_1200x1600` →
      `image.format="bmp4-spectra6-1200x1600"`, `next_checkin_sec≈3600`.
- [ ] `/terminal/{code}/image.bmp?variant=spectra6_1200x1600` → 960,118 B,
      palette[0..5] = K/W/G/B/R/Y, ETag matches schedule.
- [ ] Two check-ins within one hour → identical ETag (deterministic render).
- [ ] Render both designs against a busy and an empty `DayShape`; confirm no
      grey pixels (`convert out.bmp -unique-colors txt:` shows ≤ 6 colours).

---

## 14. Decisions register (don't change without reason)

| Decision | Why |
|---|---|
| TRMNL pixel font for everything < 24 px | Owner's choice; AA murders small type on e-ink at 150 PPI. |
| Ship Editorial (**selected**) | Owner picked the warm broadsheet (v2, with the integrated colour + halftone system). Swiss (§9) is kept as a documented fallback, not shipped. |
| Hero rotates: now → next → calm | Most hours should look calm on a wall, not like a dashboard. |
| Date is the masthead | No wordmark needed; the day is the most glanceable anchor. |
| House state limited to slow signals | It refreshes hourly — only show what's still true in an hour (floor temps, presence, garage), never live appliance timers. |
| Yellow = fills/marks only | Native panel yellow is the weakest value on white. |
| `dither=False` | FS dither shreds bitmap glyphs; the design has no greys to dither. |
| Reuse HA shape for weather/house | Don't rebuild a weather/sensor layer you already have. |

---

## 15. Open questions for the owner

1. **Direction is settled: Editorial v2.** (Swiss §9 stays documented as a
   fallback only.)
2. **Agenda window** — fixed 8 AM–8 PM, or derive from the day's first/last
   event so a 6 AM flight or a 9 PM dinner isn't clipped?
3. **Multiple calendars/people** — one person's day, or merge several
   calendars (and how to colour-code by owner vs by kind)?
4. **3-day forecast** — is daily forecast available in the HA feed, or should
   the assembler hit a weather API directly?
5. **Needs-reply selection** — newest 3, or AI-ranked "most important 3"?
6. **Quiet-hours** — overnight, switch to a minimal "tomorrow" preview, or
   `device_actions.clear_screen` until morning to save panel cycles?

End of handoff.
