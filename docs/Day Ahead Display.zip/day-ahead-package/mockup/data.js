/* ──────────────────────────────────────────────────────────────────
   Day Ahead Display — sample data layer (the "DayShape")
   Mirrors what the email/calendar backend would assemble each hour.
   Two fixtures: a BUSY weekday morning and a CALM weekend morning.
   Times are "HH:MM" 24h strings; minute integers are precomputed so
   the renderer can pick the "next" event without a date library.
   ────────────────────────────────────────────────────────────────── */
(function () {
  const M = (h, m) => h * 60 + (m || 0);

  // 12h clock label, e-ink editorial style ("8:30", "11:00", "1:00").
  function ampm(hhmm) {
    const [h, m] = hhmm.split(":").map(Number);
    const hr = ((h + 11) % 12) + 1;
    return m === 0 ? `${hr}` : `${hr}:${String(m).padStart(2, "0")}`;
  }
  function meridiem(hhmm) {
    return Number(hhmm.split(":")[0]) < 12 ? "AM" : "PM";
  }
  function durLabel(a, b) {
    const d = M(...b.split(":").map(Number)) - M(...a.split(":").map(Number));
    if (d % 60 === 0) return `${d / 60}h`;
    if (d < 60) return `${d}m`;
    return `${Math.floor(d / 60)}h${d % 60}m`;
  }
  // relative-to-now label: "now", "in 25m", "in 3h", "9:00"
  function relLabel(startMin, nowMin) {
    const d = startMin - nowMin;
    if (d <= 0) return "now";
    if (d < 60) return `in ${d}m`;
    if (d < 240) return d % 60 === 0 ? `in ${d / 60}h` : `in ${Math.floor(d / 60)}h${d % 60}m`;
    return null;
  }

  const KIND_ACCENT = { meeting: "blue", focus: "ink", personal: "green", travel: "yellow" };

  function decorate(day) {
    day.M = M;
    for (const e of day.events) {
      e.startMin = M(...e.start.split(":").map(Number));
      e.endMin = M(...e.end.split(":").map(Number));
      e.startLabel = ampm(e.start);
      e.startMer = meridiem(e.start);
      e.dur = durLabel(e.start, e.end);
      e.accent = KIND_ACCENT[e.kind] || "ink";
      e.happeningNow = day.nowMin >= e.startMin && day.nowMin < e.endMin;
    }
    const upcoming = day.events
      .filter((e) => e.endMin > day.nowMin)
      .sort((a, b) => a.startMin - b.startMin);
    day.remaining = upcoming;
    day.nextEvent = upcoming[0] || null;
    if (day.nextEvent) {
      day.nextEvent.rel = day.nextEvent.happeningNow
        ? "now"
        : relLabel(day.nextEvent.startMin, day.nowMin);
    }
    day.calm =
      day.remaining.length === 0 &&
      day.mail.needsReply.count === 0 &&
      day.todos.overdue === 0;
    return day;
  }

  window.DAY_HELPERS = { ampm, meridiem, durLabel, relLabel, M, KIND_ACCENT };

  // ── BUSY weekday: Thursday, June 5 2026, 8:00 AM ─────────────────
  window.DAY_BUSY = decorate({
    tz: "America/New_York",
    asOf: "8:00 AM",
    nowMin: M(8, 0),
    date: { weekday: "THURSDAY", monthDay: "JUNE 5", year: "2026", iso: "2026 · 06 · 05", dow3: "THU" },
    weather: {
      now: { temp: 61, code: "partly", label: "Partly cloudy" },
      hi: 74, lo: 58, sunrise: "5:18", sunset: "8:24",
      forecast: [
        { dow: "FRI", code: "sunny", hi: 78, lo: 60 },
        { dow: "SAT", code: "rain", hi: 66, lo: 55 },
        { dow: "SUN", code: "cloudy", hi: 71, lo: 57 },
      ],
    },
    events: [
      { id: 1, start: "08:30", end: "09:00", title: "Morning review", loc: "Desk", kind: "focus" },
      { id: 2, start: "11:00", end: "11:30", title: "Design standup", loc: "Conf Room B", kind: "meeting", people: 5 },
      { id: 3, start: "13:00", end: "14:00", title: "Lunch with Dana", loc: "Café Algiers", kind: "personal" },
      { id: 4, start: "15:30", end: "16:30", title: "Quarterly planning", loc: "Zoom", kind: "meeting", people: 9 },
      { id: 5, start: "18:00", end: "19:00", title: "Groceries + dinner", loc: "Market Basket", kind: "personal" },
    ],
    mail: {
      needsReply: {
        count: 3,
        top: [
          { from: "Marisa Chen", subj: "Re: contract redlines", age: "2d" },
          { from: "Dad", subj: "Fwd: flight options for July", age: "1d" },
          { from: "Stripe", subj: "Invoice #4471 needs approval", age: "5h" },
        ],
      },
      awaiting: 4,
      unread: 28,
    },
    todos: {
      count: 3, overdue: 1,
      dueToday: [
        { title: "Send Q3 budget to Marisa", overdue: true },
        { title: "Review PR #482", overdue: false },
        { title: "Call dentist back", overdue: false },
      ],
    },
    house: {
      temps: { outdoor: 61, first: 70, second: 71, third: 72, basement: 68 },
      people: [ { name: "Andrew", home: true }, { name: "Sam", home: false } ],
      advisory: "Garage open",
    },
    tomorrow: { first: { start: "9:00", title: "Dentist — cleaning", loc: "Dr. Okafor" } },
  });

  // ── CALM weekend: Saturday, June 7 2026, 9:00 AM ─────────────────
  window.DAY_CALM = decorate({
    tz: "America/New_York",
    asOf: "6:30 PM",
    nowMin: M(18, 30),
    date: { weekday: "SATURDAY", monthDay: "JUNE 7", year: "2026", iso: "2026 · 06 · 07", dow3: "SAT" },
    weather: {
      now: { temp: 72, code: "clear", label: "Clear" },
      hi: 79, lo: 61, sunrise: "5:17", sunset: "8:26",
      forecast: [
        { dow: "SUN", code: "sunny", hi: 81, lo: 63 },
        { dow: "MON", code: "partly", hi: 76, lo: 60 },
        { dow: "TUE", code: "rain", hi: 64, lo: 54 },
      ],
    },
    events: [],
    mail: { needsReply: { count: 0, top: [] }, awaiting: 1, unread: 4 },
    todos: { count: 0, overdue: 0, dueToday: [] },
    house: {
      temps: { outdoor: 67, first: 71, second: 72, third: 73, basement: 69 },
      people: [ { name: "Andrew", home: true }, { name: "Sam", home: true } ],
      advisory: "",
    },
    tomorrow: { first: { start: "9:30", title: "Brunch with Etta", loc: "Tatte" } },
  });
})();
