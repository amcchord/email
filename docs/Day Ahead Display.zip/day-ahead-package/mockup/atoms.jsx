/* Shared e-ink atoms for both Day Ahead directions.
   Exposed on window so each script can use them. IIFE-wrapped so its
   top-level names stay file-scoped under classic <script> loading. */
(function () {
const { createElement: h } = React;

/* Weather glyph — hand-built from primitives only (circles + strokes),
   the e-ink rule: no icon fonts (they alias), no gradients. Pure ink so
   it stays legible at distance; yellow reads weak on white e-ink. */
function WeatherGlyph({ code, size = 48, stroke = 3, color = "#111" }) {
  const s = size, c = s / 2;
  const line = (x1, y1, x2, y2, w = stroke) =>
    h("line", { x1, y1, x2, y2, stroke: color, strokeWidth: w, strokeLinecap: "round" });
  let kids = [];
  if (code === "sunny" || code === "clear") {
    const r = s * 0.20;
    kids.push(h("circle", { cx: c, cy: c, r, fill: "none", stroke: color, strokeWidth: stroke }));
    for (let i = 0; i < 8; i++) {
      const a = (Math.PI / 4) * i;
      const r1 = r + s * 0.10, r2 = r + s * 0.22;
      kids.push(line(c + Math.cos(a) * r1, c + Math.sin(a) * r1, c + Math.cos(a) * r2, c + Math.sin(a) * r2, stroke));
    }
  } else if (code === "partly") {
    const r = s * 0.16, sx = s * 0.36, sy = s * 0.34;
    kids.push(h("circle", { cx: sx, cy: sy, r, fill: "none", stroke: color, strokeWidth: stroke }));
    for (let i = 0; i < 8; i++) {
      const a = (Math.PI / 4) * i;
      const r1 = r + s * 0.07, r2 = r + s * 0.15;
      kids.push(line(sx + Math.cos(a) * r1, sy + Math.sin(a) * r1, sx + Math.cos(a) * r2, sy + Math.sin(a) * r2, stroke - 0.5));
    }
    kids.push(cloud(s, c, s * 0.62, color, stroke, 0.46));
  } else if (code === "cloudy") {
    kids.push(cloud(s, c, c + s * 0.04, color, stroke, 0.52));
  } else if (code === "rain") {
    kids.push(cloud(s, c, s * 0.42, color, stroke, 0.5));
    for (let i = 0; i < 3; i++) {
      const x = s * 0.32 + i * s * 0.18;
      kids.push(line(x, s * 0.72, x - s * 0.06, s * 0.9, stroke));
    }
  } else {
    kids.push(h("text", { x: c, y: c + s * 0.12, textAnchor: "middle", fontSize: s * 0.5, fill: color }, "?"));
  }
  return h("svg", { width: s, height: s, viewBox: `0 0 ${s} ${s}`, style: { display: "block" } },
    kids.map((el, i) => React.cloneElement(el, { key: i })));
}

function cloud(s, cx, cy, color, stroke, scale) {
  const w = s * scale;
  return h("path", {
    key: "cloud",
    d: cloudPath(cx, cy, w),
    fill: "none", stroke: color, strokeWidth: stroke, strokeLinejoin: "round",
  });
}
function cloudPath(cx, cy, w) {
  const r = w * 0.5, x = cx - w * 0.72, y = cy;
  return `M ${x + r * 0.2} ${y + r * 0.55}
    a ${r * 0.55} ${r * 0.55} 0 0 1 ${r * 0.2} ${-r * 1.0}
    a ${r * 0.6} ${r * 0.6} 0 0 1 ${r * 1.05} ${-r * 0.2}
    a ${r * 0.5} ${r * 0.5} 0 0 1 ${r * 0.55} ${r * 0.95}
    z`;
}

/* Rotated-square diamond ornament (real square, not the ◆ glyph which
   renders inconsistently). */
function Diamond({ size = 9, color = "#111", style = {} }) {
  return h("span", {
    style: {
      display: "inline-block", width: size, height: size,
      background: color, transform: "rotate(45deg)", ...style,
    },
  });
}

/* Presence dot: filled = home, hollow = away. */
function Dot({ size = 12, color = "#111", filled = true }) {
  return h("span", {
    style: {
      display: "inline-block", width: size, height: size, borderRadius: "50%",
      background: filled ? color : "transparent",
      border: `2px solid ${color}`, boxSizing: "border-box",
    },
  });
}

Object.assign(window, { WeatherGlyph, Diamond, Dot });
})();
