/* ──────────────────────────────────────────────────────────────────
   DAY AHEAD — Direction B · SWISS (modular agenda grid, portrait)
   1200×1600. Müller-Brockmann grid: ink-on-ink register, ISO section
   labels (NN / NAME · STATE), Helvetica display numerics, a true
   time-ruled agenda with a red NOW line, inverted cells when "hot".
   TRMNL pixel fonts for every label ≤ 21px. No grey, no gradient.
   Exposes window.SwissPortrait, window.SW_PALETTE.
   ────────────────────────────────────────────────────────────────── */
(function () {
const { createElement: ce } = React;
const SWG  = (p) => React.createElement(window.WeatherGlyph, p);
const SDia = (p) => React.createElement(window.Diamond, p);
const SDot = (p) => React.createElement(window.Dot, p);

const SW_PALETTE = {
  six: { bg: "#ffffff", ink: "#0a0a0a", red: "#c8261b", blue: "#1d4d8a",
         green: "#1f6b3a", yellow: "#caa200", rule: "#0a0a0a" },
  bw:  { bg: "#ffffff", ink: "#000000", red: "#000000", blue: "#000000",
         green: "#000000", yellow: "#000000", rule: "#000000" },
};
const HELV = '"Helvetica Neue", Helvetica, Arial, sans-serif';
const sacc = (P, k) => (k && P[k]) || P.ink;
const isBW = (P) => P.red === P.ink;
const fillColor = (P, k) => (isBW(P) ? P.ink : sacc(P, k));

/* ── atoms ─────────────────────────────────────────────────────── */
function SectionLabel({ P, n, name, state, color, invert }) {
  const c = invert ? P.bg : (color || P.ink);
  return ce("div", { style: { display: "flex", alignItems: "baseline", gap: 8 } },
    ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.04em", color: c } }, n),
    ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.14em", color: c } },
      "/ " + name + (state ? " · " + state : "")));
}
function Cell({ P, children, style = {}, invert, accent }) {
  const bg = invert ? fillColor(P, accent) : P.bg;
  return ce("div", { style: { boxSizing: "border-box", padding: "14px 18px", background: bg, ...style } }, children);
}

/* ── header: ink-on-ink date register ──────────────────────────── */
function Header({ day, P }) {
  const active = (day.mail.needsReply.count > 0 || day.todos.overdue > 0 || day.remaining.length > 0);
  const activeN = day.remaining.length;
  return ce("div", { style: { display: "grid", gridTemplateColumns: "300px 1fr auto", alignItems: "stretch", borderBottom: `3px solid ${P.rule}` } },
    ce("div", { style: { background: P.ink, color: P.bg, padding: "16px 18px", display: "flex", flexDirection: "column", justifyContent: "center" } },
      ce("span", { className: "pix21", style: { fontWeight: 700, letterSpacing: "0.10em", color: P.bg } }, day.date.iso),
      ce("span", { className: "pix16", style: { letterSpacing: "0.22em", color: P.bg, marginTop: 4 } }, day.date.weekday)),
    ce("div", { style: { display: "flex", alignItems: "center", padding: "0 18px", borderRight: `2px solid ${P.rule}`, borderLeft: `2px solid ${P.rule}` } },
      ce("span", { className: "pix21", style: { fontWeight: 700, letterSpacing: "0.20em", color: P.ink } }, "DAY AHEAD")),
    ce("div", { style: { display: "flex", alignItems: "center", gap: 16, padding: "0 18px" } },
      active && ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.06em", color: P.bg, background: fillColor(P, "red"), padding: "5px 8px" } },
        `● ${activeN} AHEAD`),
      ce("span", { className: "pix16", style: { letterSpacing: "0.10em", color: P.ink } }, `↻ ${to24(day.asOf)}`)));
}

/* ── hero: next event (left) + weather now (right) ─────────────── */
function Hero({ day, P }) {
  return ce("div", { style: { display: "grid", gridTemplateColumns: "1fr 340px", borderBottom: `3px solid ${P.rule}` } },
    day.calm ? ce(HeroCalm, { day, P }) : ce(HeroNext, { day, P }),
    ce(WeatherCell, { day, P }));
}
function HeroNext({ day, P }) {
  const e = day.nextEvent;
  const now = e.happeningNow;
  const aK = now ? "blue" : (e.startMin - day.nowMin <= 30 ? "red" : e.accent);
  const invert = now;
  const fg = invert ? P.bg : P.ink;
  const accodd = invert ? P.bg : sacc(P, aK);
  return ce("div", { style: { padding: "18px 22px 20px", background: invert ? fillColor(P, "blue") : P.bg, display: "flex", flexDirection: "column", justifyContent: "space-between", minHeight: 290, boxSizing: "border-box" } },
    ce(SectionLabel, { P, n: "00", name: now ? "NOW" : "UP NEXT", state: now ? "" : (e.rel ? e.rel.toUpperCase() : null), color: accodd, invert }),
    ce("div", { style: { marginTop: 6 } },
      ce("div", { style: { display: "flex", alignItems: "baseline", gap: 14 } },
        ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 132, lineHeight: 0.82, letterSpacing: "-0.05em", color: accodd } }, e.startLabel),
        ce("span", { className: "pix21", style: { fontWeight: 700, color: fg } }, e.startMer)),
      ce("div", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 44, letterSpacing: "-0.02em", color: fg, marginTop: 10, lineHeight: 1.0 } }, e.title)),
    ce("div", { style: { display: "flex", gap: 10, flexWrap: "wrap" } },
      ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.08em", color: fg, border: `2px solid ${fg}`, padding: "4px 8px" } }, e.loc.toUpperCase()),
      ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.08em", color: fg, border: `2px solid ${fg}`, padding: "4px 8px" } }, e.dur.toUpperCase()),
      e.people && ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.08em", color: fg, border: `2px solid ${fg}`, padding: "4px 8px" } }, e.people + " PEOPLE")));
}
function HeroCalm({ day, P }) {
  return ce("div", { style: { padding: "18px 22px 20px", display: "flex", flexDirection: "column", justifyContent: "space-between", minHeight: 290, boxSizing: "border-box" } },
    ce(SectionLabel, { P, n: "00", name: "ALL CLEAR", state: "", color: sacc(P, "green") }),
    ce("div", { style: { display: "flex", alignItems: "center", gap: 24, marginTop: 4 } },
      ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 168, lineHeight: 0.8, letterSpacing: "-0.05em", color: "transparent", WebkitTextStroke: `3px ${P.ink}` } }, "0"),
      ce("div", null,
        ce("div", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 40, letterSpacing: "-0.02em", color: P.ink, lineHeight: 1.0 } }, "Nothing"),
        ce("div", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 40, letterSpacing: "-0.02em", color: P.ink, lineHeight: 1.0 } }, "scheduled."))),
    ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.08em", color: P.ink, border: `2px solid ${P.ink}`, padding: "4px 8px", alignSelf: "flex-start" } },
      `NEXT · TOMORROW ${day.tomorrow.first.start}`));
}
function WeatherCell({ day, P }) {
  const w = day.weather;
  return ce("div", { style: { borderLeft: `2px solid ${P.rule}`, display: "flex", flexDirection: "column" } },
    ce("div", { style: { padding: "14px 18px 12px" } },
      ce(SectionLabel, { P, n: "01", name: "WEATHER", state: w.now.label.toUpperCase() }),
      ce("div", { style: { display: "flex", alignItems: "center", gap: 14, marginTop: 8 } },
        ce(SWG, { code: w.now.code, size: 56, stroke: 3, color: P.ink }),
        ce("div", { style: { display: "flex", alignItems: "flex-start" } },
          ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 72, lineHeight: 0.84, letterSpacing: "-0.04em", color: P.ink } }, w.now.temp),
          ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 26, color: P.ink } }, "°"))),
      ce("div", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink, marginTop: 6 } }, `HI ${w.hi}°  LO ${w.lo}°`)),
    ce("div", { style: { borderTop: `2px solid ${P.rule}`, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", flex: 1 } },
      w.forecast.map((f, i) =>
        ce("div", { key: i, style: { borderLeft: i ? `2px solid ${P.rule}` : "none", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, padding: "8px 0" } },
          ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.08em", color: P.ink } }, f.dow),
          ce(SWG, { code: f.code, size: 28, stroke: 2.5, color: P.ink }),
          ce("span", { className: "pix16", style: { color: P.ink } }, `${f.hi}°`)))));
}

/* ── agenda grid: time-ruled day planner with a NOW line ───────── */
const DAY_START = 8 * 60, DAY_END = 20 * 60, GRID_H = 820, GUTTER = 92;
function Agenda({ day, P }) {
  const span = DAY_END - DAY_START;
  const y = (min) => Math.max(0, Math.min(GRID_H, ((min - DAY_START) / span) * GRID_H));
  const hours = [];
  for (let hMin = DAY_START; hMin <= DAY_END; hMin += 60) hours.push(hMin);
  const nowY = y(day.nowMin);
  const nowVisible = day.nowMin >= DAY_START && day.nowMin <= DAY_END;
  return ce("div", { style: { borderBottom: `3px solid ${P.rule}`, padding: "14px 22px 18px" } },
    ce("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 } },
      ce(SectionLabel, { P, n: "02", name: "AGENDA", state: `${day.remaining.length} AHEAD` }),
      ce("span", { className: "pix16", style: { letterSpacing: "0.10em", color: P.ink } }, "8 AM — 8 PM")),
    ce("div", { style: { position: "relative", height: GRID_H, marginLeft: GUTTER } },
      // hour rules + labels
      hours.map((hMin, i) =>
        ce("div", { key: i, style: { position: "absolute", top: y(hMin), left: -GUTTER, right: 0, height: 2, background: P.rule, opacity: i === 0 || i === hours.length - 1 ? 1 : 0.0 } })),
      hours.map((hMin, i) =>
        ce("div", { key: "h" + i, style: { position: "absolute", top: y(hMin), left: -GUTTER, right: 0, borderTop: i === 0 ? "none" : `2px ${i % 1 ? "solid" : "solid"} ${P.rule}` } },
          ce("span", { className: "pix16", style: { position: "absolute", top: -9, left: 0, color: P.ink, letterSpacing: "0.04em" } }, hourLabel(hMin)))),
      // events
      day.remaining.map((e) => ce(AgendaBlock, { key: e.id, e, P, y })),
      day.remaining.length === 0 &&
        ce("div", { style: { position: "absolute", top: GRID_H / 2 - 14, left: 0, right: 0, textAlign: "center" } },
          ce("span", { className: "pix21", style: { letterSpacing: "0.16em", color: P.ink } }, "NOTHING SCHEDULED TODAY")),
      // NOW line
      nowVisible && ce("div", { style: { position: "absolute", top: nowY, left: -GUTTER, right: 0, height: 3, background: fillColor(P, "red") } }),
      nowVisible && ce("span", { className: "pix16", style: { position: "absolute", top: nowY - 20, left: -GUTTER, fontWeight: 700, letterSpacing: "0.08em", color: fillColor(P, "red") } }, "NOW " + to24(day.asOf))));
}
function AgendaBlock({ e, P, y }) {
  const top = y(e.startMin), bottom = y(e.endMin);
  const hgt = Math.max(30, bottom - top);
  const a = sacc(P, e.accent);
  const invert = e.happeningNow;
  const bg = invert ? fillColor(P, e.accent) : P.bg;
  const fg = invert ? P.bg : P.ink;
  return ce("div", { style: { position: "absolute", top, left: 6, right: 0, height: hgt, background: bg, borderLeft: `6px solid ${a}`, boxSizing: "border-box", padding: "5px 10px", overflow: "hidden", boxShadow: `0 0 0 2px ${P.bg}` } },
    ce("div", { style: { display: "flex", alignItems: "baseline", gap: 10 } },
      ce("span", { className: "pix21", style: { fontWeight: 700, color: invert ? P.bg : a } }, e.startLabel + e.startMer.toLowerCase()),
      ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: hgt < 46 ? 21 : 25, letterSpacing: "-0.01em", color: fg, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, e.title)),
    hgt >= 50 && ce("div", { className: "pix16", style: { letterSpacing: "0.06em", color: fg, marginTop: 3 } },
      `${e.loc.toUpperCase()} · ${e.dur.toUpperCase()}${e.people ? " · " + e.people + "P" : ""}`));
}

/* ── bottom cells: inbox / tasks / house ───────────────────────── */
function BottomCells({ day, P }) {
  return ce("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", borderBottom: `3px solid ${P.rule}` } },
    ce(InboxCell, { day, P }),
    ce(TasksCell, { day, P, mid: true }),
    ce(HouseCell, { day, P }));
}
function InboxCell({ day, P }) {
  const nr = day.mail.needsReply;
  const hot = nr.count > 0;
  const invert = hot;
  const fg = invert ? P.bg : P.ink;
  return ce(Cell, { P, invert, accent: "red", style: { minHeight: 230, borderRight: `2px solid ${P.rule}` } },
    ce(SectionLabel, { P, n: "03", name: "INBOX", state: hot ? "NEEDS REPLY" : "CLEAR", invert, color: hot ? null : sacc(P, "green") }),
    ce("div", { style: { display: "flex", alignItems: "baseline", gap: 12, margin: "8px 0 4px" } },
      ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 76, lineHeight: 0.8, letterSpacing: "-0.04em", color: fg } }, nr.count),
      ce("span", { className: "pix16", style: { color: fg, letterSpacing: "0.06em" } }, `${day.mail.awaiting} AWAIT\n${day.mail.unread} UNREAD`.split("\n").map((t, i) => ce("div", { key: i }, t)))),
    ce("div", { style: { height: 2, background: fg, opacity: 0.5, margin: "8px 0" } }),
    hot
      ? nr.top.slice(0, 3).map((r, i) => ce("div", { key: i, style: { display: "flex", justifyContent: "space-between", gap: 8, padding: "3px 0" } },
          ce("span", { className: "pix16", style: { fontWeight: 700, color: fg, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, r.from.toUpperCase()),
          ce("span", { className: "pix16", style: { color: fg } }, r.age)))
      : ce("span", { className: "pix16", style: { color: fg, letterSpacing: "0.06em" } }, "NO ONE IS WAITING."));
}
function TasksCell({ day, P, mid }) {
  const t = day.todos;
  const hot = t.overdue > 0;
  return ce(Cell, { P, style: { minHeight: 230, borderRight: `2px solid ${P.rule}` } },
    ce(SectionLabel, { P, n: "04", name: "TASKS", state: t.count ? `${t.count} DUE` : "NONE", color: hot ? sacc(P, "red") : (t.count ? P.ink : sacc(P, "green")) }),
    ce("div", { style: { display: "flex", alignItems: "baseline", gap: 12, margin: "8px 0 4px" } },
      ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 76, lineHeight: 0.8, letterSpacing: "-0.04em", color: P.ink } }, t.count),
      hot && ce("span", { className: "pix16", style: { fontWeight: 700, color: P.bg, background: fillColor(P, "red"), padding: "3px 6px", letterSpacing: "0.06em" } }, `${t.overdue} OVERDUE`)),
    ce("div", { style: { height: 2, background: P.ink, opacity: 0.5, margin: "8px 0" } }),
    t.count
      ? t.dueToday.slice(0, 3).map((td, i) => ce("div", { key: i, style: { display: "flex", gap: 8, alignItems: "baseline", padding: "3px 0" } },
          ce(SDia, { size: 8, color: td.overdue ? sacc(P, "red") : P.ink }),
          ce("span", { className: "pix16", style: { color: P.ink, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, td.title)))
      : ce("span", { className: "pix16", style: { color: P.ink, letterSpacing: "0.06em" } }, "ALL CAUGHT UP."));
}
function HouseCell({ day, P }) {
  const t = day.house.temps;
  const floors = [["3F", t.third], ["2F", t.second], ["1F", t.first], ["BS", t.basement]];
  return ce(Cell, { P, style: { minHeight: 230 } },
    ce(SectionLabel, { P, n: "05", name: "HOUSE", state: `${t.outdoor}° OUT` }),
    ce("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2px 16px", margin: "10px 0 6px" } },
      floors.map((f, i) => ce("div", { key: i, style: { display: "flex", justifyContent: "space-between", alignItems: "baseline" } },
        ce("span", { className: "pix16", style: { letterSpacing: "0.10em", color: P.ink } }, f[0]),
        ce("span", { style: { fontFamily: HELV, fontWeight: 700, fontSize: 22, color: P.ink } }, f[1] + "°")))),
    ce("div", { style: { height: 2, background: P.ink, opacity: 0.5, margin: "6px 0 8px" } }),
    ce("div", { style: { display: "flex", flexDirection: "column", gap: 5 } },
      day.house.people.map((p, i) => ce("div", { key: i, style: { display: "flex", alignItems: "center", gap: 7 } },
        ce(SDot, { size: 12, color: p.home ? sacc(P, "green") : P.ink, filled: p.home }),
        ce("span", { className: "pix16", style: { letterSpacing: "0.06em", color: P.ink } }, `${p.name.toUpperCase()} ${p.home ? "HOME" : "OUT"}`))),
      day.house.advisory && ce("div", { style: { display: "flex", alignItems: "center", gap: 7 } },
        ce(SDia, { size: 8, color: sacc(P, "yellow") }),
        ce("span", { className: "pix16", style: { letterSpacing: "0.06em", color: P.ink } }, day.house.advisory.toUpperCase()))));
}

/* ── footer ────────────────────────────────────────────────────── */
function Footer({ day, P }) {
  const nr = day.mail.needsReply, t = day.tomorrow.first;
  const attn = nr.count > 0 ? `▲ ${nr.count} NEED REPLY` : "▲ INBOX CLEAR";
  return ce("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", alignItems: "center", height: 46 } },
    ce("span", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink, padding: "0 18px" } }, "SRC · MAIL + CAL"),
    ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.06em", color: nr.count > 0 ? sacc(P, "red") : P.ink, textAlign: "center" } }, attn),
    ce("span", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink, textAlign: "right", padding: "0 18px" } }, `TMRW ${t.start} ${t.title.toUpperCase().slice(0, 14)}`));
}

function hourLabel(min) { const h = Math.floor(min / 60); return (h > 12 ? h - 12 : h) + (h < 12 ? "A" : "P"); }
function to24(asOf) {
  // "8:00 AM" -> "08:00"
  const m = asOf.match(/(\d+):(\d+)\s*(AM|PM)/i); if (!m) return asOf;
  let h = +m[1]; const mer = m[3].toUpperCase();
  if (mer === "PM" && h !== 12) h += 12; if (mer === "AM" && h === 12) h = 0;
  return String(h).padStart(2, "0") + ":" + m[2];
}

/* ── frame ─────────────────────────────────────────────────────── */
function SwissPortrait({ day, palette = "six" }) {
  const P = SW_PALETTE[palette] || SW_PALETTE.six;
  return ce("div", { style: {
      width: 1200, height: 1600, background: P.bg, color: P.ink, boxSizing: "border-box",
      fontFamily: HELV, display: "flex", flexDirection: "column", overflow: "hidden",
      border: `3px solid ${P.rule}` } },
    ce(Header, { day, P }),
    ce(Hero, { day, P }),
    ce(Agenda, { day, P }),
    ce(BottomCells, { day, P }),
    ce("div", { style: { flex: 1 } }),
    ce("div", { style: { borderTop: `3px solid ${P.rule}` } }, ce(Footer, { day, P })));
}

Object.assign(window, { SwissPortrait, SW_PALETTE });
})();
