/* ──────────────────────────────────────────────────────────────────
   DAY AHEAD — Direction A · EDITORIAL v2 (illustrated broadsheet)
   1200×1600. The date is the masthead. Source Serif 4 for display type,
   TRMNL pixel fonts for every label ≤ 21px.
   COLOUR SYSTEM (6-colour Spectra, integrated as information + ornament):
     · highs = RED, lows = BLUE, comfort-now coloured warm/cool
     · meetings = BLUE, personal = GREEN, focus = INK, travel = GOLD
     · needs-you / now / overdue = RED
     · DUOTONE HALFTONES mix native inks into new hues, in decorative
       fields ONLY (never under text): yellow field + red dots = ORANGE
       sun; blue dots on white = light-blue SKY. On device these become
       ordered (Bayer) dithers of the same two inks.
   Exposes window.EditorialPortrait, window.DA_E_PALETTE.
   ────────────────────────────────────────────────────────────────── */
(function () {
const { createElement: ce } = React;
const EWG  = (p) => React.createElement(window.WeatherGlyph, p);
const EDia = (p) => React.createElement(window.Diamond, p);
const EDot = (p) => React.createElement(window.Dot, p);

const DA_E_PALETTE = {
  six: { bg: "#ffffff", ink: "#15110c", paper: "#f5efe4", red: "#c8261b",
         blue: "#1d4d8a", green: "#1f6b3a", yellow: "#e6c33a", rule: "#15110c" },
  bw:  { bg: "#ffffff", ink: "#000000", paper: "#ffffff", red: "#000000",
         blue: "#000000", green: "#000000", yellow: "#000000", rule: "#000000" },
};
const SERIF = '"Source Serif 4", Georgia, "Times New Roman", serif';
const acc = (P, k) => (k && P[k]) || P.ink;
const KIND = { meeting: "blue", focus: "ink", personal: "green", travel: "yellow" };

/* ── halftone helpers (simulate ordered dither in the browser) ──── */
function dots(color, cell, r) {
  return {
    backgroundImage: `radial-gradient(circle at 50% 50%, ${color} ${r}px, transparent ${r + 0.6}px)`,
    backgroundSize: `${cell}px ${cell}px`,
  };
}
function duo(c1, c2, cell, r) {
  return {
    backgroundImage:
      `radial-gradient(circle at 50% 50%, ${c1} ${r}px, transparent ${r + 0.6}px),` +
      `radial-gradient(circle at 50% 50%, ${c2} ${r}px, transparent ${r + 0.6}px)`,
    backgroundSize: `${cell}px ${cell}px, ${cell}px ${cell}px`,
    backgroundPosition: `0 0, ${cell / 2}px ${cell / 2}px`,
  };
}
function tempColor(P, t, kind) {
  if (P.red === P.ink) return P.ink;          // bw
  if (kind === "hi") return P.red;
  if (kind === "lo") return P.blue;
  if (t >= 72) return P.red;
  if (t <= 55) return P.blue;
  return P.ink;
}
/* time-of-day sky: a dithered density-ramp behind the masthead that
   shifts hue with the hour (warm at dawn/dusk, blue midday, deep at night). */
const SKY_PERIOD = (nowMin) => {
  const h = (nowMin || 0) / 60;
  if (h < 5) return "night";
  if (h < 8) return "dawn";
  if (h < 11) return "morning";
  if (h < 15) return "midday";
  if (h < 18) return "afternoon";
  if (h < 21) return "dusk";
  return "night";
};
const SKY_SPEC = (P) => ({
  dawn:      ["duo", P.yellow, P.red],    // sunrise
  morning:   ["single", P.blue],          // clear blue
  midday:    ["single", P.blue],
  afternoon: ["duo", P.yellow, P.red],    // warm gold
  dusk:      ["duo", P.blue, P.red],      // violet sunset
  night:     ["single", P.blue],          // deep blue
});
function SkyGradient({ nowMin, P }) {
  const isbw = P.red === P.ink;
  const period = SKY_PERIOD(nowMin);
  const spec = isbw ? ["single", P.ink] : SKY_SPEC(P)[period];
  const steps = 11, cell = 6, rMax = isbw ? 0.85 : (period === "night" ? 2.1 : 1.8);
  const bands = [];
  for (let i = 0; i < steps; i++) {
    const f = 1 - i / (steps - 1);              // 1 at top → 0 at baseline
    const r = +(rMax * f).toFixed(2);
    if (r < 0.34) continue;
    const st = spec[0] === "duo" ? duo(spec[1], spec[2], cell, r) : dots(spec[1], cell, r);
    bands.push(ce("div", { key: i, style: { position: "absolute", left: 0, right: 0, top: `${(i * 100) / steps}%`, height: `${100 / steps + 0.7}%`, ...st } }));
  }
  return ce("div", { style: { position: "absolute", inset: 0, pointerEvents: "none" } }, bands);
}

/* ── weather stamp (pure black & white) ────────────────────────── */
function WeatherStamp({ code, size, P }) {
  return ce("div", { style: { position: "relative", width: size, height: size, borderRadius: "50%", overflow: "hidden", border: `2.5px solid ${P.ink}`, background: P.bg, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" } },
    ce(EWG, { code, size: Math.round(size * 0.72), stroke: 3, color: P.ink }));
}

/* ── atoms ─────────────────────────────────────────────────────── */
function Hr({ P, w = 2, color, mt = 0, mb = 0 }) {
  return ce("div", { style: { height: w, background: color || P.rule, marginTop: mt, marginBottom: mb } });
}
function SpotRule({ P, color, mt = 0, mb = 0 }) {
  return ce("div", { style: { height: 2, background: P.red === P.ink ? P.ink : (color || P.red), marginTop: mt, marginBottom: mb } });
}
function KickerTab({ P, color, children }) {
  const c = P.red === P.ink ? P.ink : (color || P.ink);
  return ce("div", { style: { display: "flex", alignItems: "center", gap: 12, marginBottom: 12 } },
    ce("span", { className: "pix21", style: { fontWeight: 700, letterSpacing: "0.14em", color: P.bg, background: c, padding: "6px 11px 5px", textTransform: "uppercase", whiteSpace: "nowrap" } }, children),
    ce("div", { style: { flex: 1, height: 4, background: c } }),
    ce("div", { style: { width: 10, height: 10, background: c, transform: "rotate(45deg)" } }));
}
function Kicker({ P, children, color, rule = true }) {
  const c = color || P.ink;
  return ce("div", { style: { display: "flex", alignItems: "center", gap: 12, marginBottom: 12 } },
    ce("div", { style: { width: 10, height: 10, background: c, transform: "rotate(45deg)" } }),
    ce("span", { className: "pix21", style: { fontWeight: 700, letterSpacing: "0.15em", color: c, textTransform: "uppercase", whiteSpace: "nowrap" } }, children),
    rule && ce("div", { style: { flex: 1, height: 2, background: P.rule } }));
}

/* ── masthead: the date IS the identity ────────────────────────── */
function Masthead({ day, P }) {
  const d = day.date;
  return ce("div", null,
    ce("div", { style: { position: "relative", overflow: "hidden", padding: "12px 0 16px" } },
      ce(SkyGradient, { nowMin: day.nowMin, P }),
      ce("div", { style: { position: "relative" } },
        ce("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 2px 6px" } },
          ce("span", { className: "pix16", style: { letterSpacing: "0.14em", color: P.ink } }, `AS OF ${day.asOf.toUpperCase()}`),
          ce("span", { className: "pix16", style: { letterSpacing: "0.22em", color: P.ink } }, "THE DAY AHEAD")),
        ce("div", { style: { textAlign: "center", lineHeight: 0.9 } },
          ce("div", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 134, letterSpacing: "-0.035em", color: P.ink } }, d.weekday)),
        ce("div", { style: { display: "flex", justifyContent: "center", alignItems: "center", gap: 14, marginTop: 8, whiteSpace: "nowrap" } },
          ce("div", { style: { width: 9, height: 9, background: acc(P, "red"), transform: "rotate(45deg)" } }),
          ce("span", { style: { fontFamily: SERIF, fontWeight: 600, fontSize: 40, color: P.ink, letterSpacing: "0.01em" } }, d.monthDay),
          ce("span", { style: { fontFamily: SERIF, fontStyle: "italic", fontWeight: 400, fontSize: 36, color: P.ink } }, d.year),
          ce("div", { style: { width: 9, height: 9, background: acc(P, "blue"), transform: "rotate(45deg)" } })))),
    ce(Hr, { P, w: 2, color: acc(P, "red"), mt: 6 }));
}

/* ── weather band ──────────────────────────────────────────────── */
function WeatherBand({ day, P }) {
  const w = day.weather;
  return ce("div", { style: { display: "flex", alignItems: "stretch", marginTop: 16 } },
    ce("div", { style: { display: "flex", alignItems: "center", gap: 18, paddingRight: 26 } },
      ce(WeatherStamp, { code: w.now.code, size: 104, P }),
      ce("div", null,
        ce("div", { style: { display: "flex", alignItems: "flex-start" } },
          ce("span", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 84, lineHeight: 0.86, color: tempColor(P, w.now.temp, "now") } }, w.now.temp),
          ce("span", { style: { fontFamily: SERIF, fontWeight: 600, fontSize: 32, color: tempColor(P, w.now.temp, "now"), marginTop: 4 } }, "°")),
        ce("div", { className: "pix16", style: { letterSpacing: "0.1em", color: P.ink, marginTop: 2 } }, w.now.label.toUpperCase()),
        ce("div", { style: { display: "flex", gap: 12, marginTop: 6 } },
          ce("span", { className: "pix16", style: { color: acc(P, "red") } }, `HI ${w.hi}°`),
          ce("span", { className: "pix16", style: { color: acc(P, "blue") } }, `LO ${w.lo}°`)))),
    ce("div", { style: { width: 2, background: P.rule, margin: "6px 0" } }),
    ...w.forecast.map((f, i) =>
      ce("div", { key: i, style: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6, borderRight: i < 2 ? `2px solid ${P.rule}` : "none" } },
        ce("span", { className: "pix16", style: { fontWeight: 700, letterSpacing: "0.12em", color: P.ink } }, f.dow),
        ce(EWG, { code: f.code, size: 36, stroke: 2.5, color: P.ink }),
        ce("div", { style: { display: "flex", gap: 7 } },
          ce("span", { className: "pix21", style: { color: acc(P, "red") } }, `${f.hi}°`),
          ce("span", { className: "pix21", style: { color: acc(P, "blue") } }, `${f.lo}°`)))));
}

/* ── factstrip ─────────────────────────────────────────────────── */
function FactStrip({ P, cells, tint }) {
  const a = tint ? acc(P, tint) : P.ink;
  const tintStyle = tint && P.red !== P.ink ? dots(a, 11, 0.6) : null;
  return ce("div", null,
    ce("div", { style: { height: 2, background: a } }),
    ce("div", { style: { display: "grid", gridTemplateColumns: `repeat(${cells.length}, 1fr)`, borderBottom: `2px solid ${P.rule}`, ...(tintStyle || {}) } },
      cells.map((c, i) =>
        ce("div", { key: i, style: { padding: "11px 16px 13px", borderLeft: i ? `2px solid ${P.rule}` : "none" } },
          ce("div", { className: "pix12", style: { letterSpacing: "0.16em", color: P.ink, marginBottom: 6 } }, c.k),
          ce("div", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 27, color: c.color || P.ink, lineHeight: 1 } }, c.v),
          c.sub && ce("div", { className: "pix12", style: { letterSpacing: "0.06em", color: P.ink, marginTop: 5 } }, c.sub)))));
}

/* ── lead story ────────────────────────────────────────────────── */
function Lead({ day, P }) {
  return day.calm ? ce(LeadCalm, { day, P }) : ce(LeadEvent, { day, P });
}
function LeadEvent({ day, P }) {
  const e = day.nextEvent;
  const soon = e.happeningNow || (e.startMin - day.nowMin <= 30);
  const aK = e.happeningNow ? "red" : soon ? "red" : "blue";
  const aColor = acc(P, aK);
  const kick = e.happeningNow ? "HAPPENING NOW" : `UP NEXT · ${e.rel ? e.rel.toUpperCase() : e.startLabel + " " + e.startMer}`;
  return ce("div", null,
    ce(KickerTab, { P, color: aColor }, kick),
    ce("div", { style: { display: "flex", gap: 22, alignItems: "flex-start" } },
      ce("div", { style: { flexShrink: 0, textAlign: "right", paddingTop: 6, minWidth: 152 } },
        ce("div", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 66, lineHeight: 0.84, color: aColor } }, e.startLabel),
        ce("div", { className: "pix21", style: { color: P.ink, marginTop: 4 } }, e.startMer + " · " + e.dur)),
      ce("div", { style: { width: 4, alignSelf: "stretch", background: aColor } }),
      ce("div", { style: { flex: 1 } },
        ce("div", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 60, lineHeight: 0.97, letterSpacing: "-0.02em", color: P.ink, textWrap: "balance" } }, e.title),
        ce("div", { style: { fontFamily: SERIF, fontStyle: "italic", fontSize: 26, color: P.ink, marginTop: 10, textWrap: "pretty" } }, leadDeck(day, e)))),
    ce("div", { style: { marginTop: 18 } },
      ce(FactStrip, { P, tint: aK, cells: [
        { k: "WHEN", v: `${e.startLabel}–${window.DAY_HELPERS.ampm(min2hhmm(e.endMin))}`, sub: e.startMer },
        { k: "WHERE", v: e.loc, sub: e.people ? e.people + " PEOPLE" : e.kind.toUpperCase() },
        { k: "THEN", v: day.remaining[1] ? day.remaining[1].startLabel : "—", sub: day.remaining[1] ? day.remaining[1].title.toUpperCase().slice(0, 16) : "CLEAR" },
      ] })));
}
function periodWord(nowMin) {
  const p = SKY_PERIOD(nowMin);
  if (p === "dusk" || p === "night") return "evening";
  if (p === "midday" || p === "afternoon") return "afternoon";
  return "morning";
}
function LeadCalm({ day, P }) {
  const t = day.tomorrow.first;
  const word = periodWord(day.nowMin);
  return ce("div", null,
    ce(KickerTab, { P, color: acc(P, "green") }, "THE QUIET EDITION"),
    ce("div", { style: { display: "flex", gap: 6 } },
      ce("span", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 96, lineHeight: 0.82, color: acc(P, "green"), float: "left", paddingRight: 14, marginTop: 4 } }, "A"),
      ce("div", { style: { flex: 1 } },
        ce("div", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 60, lineHeight: 0.97, letterSpacing: "-0.02em", color: P.ink } }, ` quiet ${word} ahead.`),
        ce("div", { style: { fontFamily: SERIF, fontStyle: "italic", fontSize: 27, color: P.ink, marginTop: 10, textWrap: "pretty" } },
          `Nothing on the calendar and the inbox is clear. The ${word} is yours — enjoy it.`))),
    ce("div", { style: { marginTop: 20 } },
      ce(FactStrip, { P, tint: "green", cells: [
        { k: "INBOX", v: "CLEAR", sub: day.mail.unread + " UNREAD", color: acc(P, "green") },
        { k: "TASKS", v: "NONE DUE", sub: "ALL CAUGHT UP", color: acc(P, "green") },
        { k: "TOMORROW", v: t.start, sub: t.title.toUpperCase().slice(0, 16) },
      ] })));
}
function leadDeck(day, e) {
  if (e.happeningNow) return `In progress now${e.loc ? " — " + e.loc + "." : "."}`;
  if (e.kind === "meeting") return `${e.dur} in ${e.loc}${e.people ? ", " + e.people + " on the invite." : "."}`;
  if (e.kind === "focus") return `A ${e.dur} window to get ahead before the day fills in.`;
  if (e.kind === "personal") return `Off the clock — ${e.loc}.`;
  return `${e.dur} · ${e.loc}.`;
}

/* ── timeline ──────────────────────────────────────────────────── */
function Timeline({ day, P }) {
  const evs = day.remaining;
  return ce("div", null,
    ce(Kicker, { P }, `THE DAY · ${evs.length} AHEAD`),
    evs.length === 0
      ? ce("div", { style: { fontFamily: SERIF, fontStyle: "italic", fontSize: 26, color: P.ink, padding: "6px 0 4px" } }, "No further events scheduled today.")
      : ce("div", null, evs.map((e, i) => ce(TimelineRow, { key: e.id, e, P, last: i === evs.length - 1 }))));
}
function TimelineRow({ e, P, last }) {
  const a = acc(P, KIND[e.kind] || "ink");
  return ce("div", { style: { display: "flex", alignItems: "stretch", gap: 16, padding: "13px 0", borderBottom: last ? "none" : `2px solid ${P.rule}` } },
    ce("div", { style: { width: 122, flexShrink: 0, textAlign: "right" } },
      ce("span", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 34, color: a, lineHeight: 1 } }, e.startLabel),
      ce("span", { className: "pix12", style: { color: P.ink, marginLeft: 5 } }, e.startMer)),
    ce("div", { style: { width: 16, flexShrink: 0, display: "flex", justifyContent: "center", paddingTop: 6 } },
      ce("div", { style: { width: 12, height: 12, background: a, transform: "rotate(45deg)" } })),
    ce("div", { style: { flex: 1, minWidth: 0 } },
      ce("div", { style: { fontFamily: SERIF, fontWeight: 600, fontSize: 31, color: P.ink, lineHeight: 1.04 } }, e.title),
      ce("div", { className: "pix16", style: { letterSpacing: "0.06em", color: P.ink, marginTop: 5 } },
        `${e.loc.toUpperCase()} · ${e.dur.toUpperCase()}${e.people ? " · " + e.people + "P" : ""}`)));
}

/* ── bottom rails: needs-reply + the house ─────────────────────── */
function BottomRails({ day, P }) {
  return ce("div", { style: { display: "grid", gridTemplateColumns: "1fr 2px 1fr", gap: 26, marginTop: 4 } },
    ce(NeedsReply, { day, P }),
    ce("div", { style: { background: P.rule } }),
    ce(HouseBrief, { day, P }));
}
function NeedsReply({ day, P }) {
  const m = day.mail, nr = m.needsReply;
  const empty = nr.count === 0;
  const a = empty ? acc(P, "green") : acc(P, "red");
  return ce("div", null,
    ce(Kicker, { P, color: a, rule: false }, "NEEDS A REPLY"),
    ce("div", { style: { display: "flex", alignItems: "baseline", gap: 12, marginBottom: 6 } },
      ce("span", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 60, lineHeight: 0.9, color: a } }, empty ? "0" : nr.count),
      ce("span", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink } }, empty ? "INBOX CLEAR" : `${m.awaiting} AWAITING · ${m.unread} UNREAD`)),
    ce(Hr, { P, w: 2, mb: 8 }),
    empty
      ? ce("div", { style: { fontFamily: SERIF, fontStyle: "italic", fontSize: 22, color: P.ink } }, "No one is waiting on you.")
      : ce("div", null, nr.top.map((r, i) =>
          ce("div", { key: i, style: { padding: "7px 0", borderBottom: i < nr.top.length - 1 ? `2px solid ${P.rule}` : "none" } },
            ce("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 } },
              ce("span", { className: "pix21", style: { fontWeight: 700, color: P.ink } }, r.from.toUpperCase()),
              ce("span", { className: "pix12", style: { color: P.bg, background: acc(P, "red"), padding: "3px 6px 2px" } }, r.age)),
            ce("div", { style: { fontFamily: SERIF, fontStyle: "italic", fontSize: 21, color: P.ink, marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, r.subj)))));
}
function HouseBrief({ day, P }) {
  const t = day.house.temps;
  const floors = [["3F", t.third], ["2F", t.second], ["1F", t.first], ["BSMT", t.basement]];
  return ce("div", null,
    ce(Kicker, { P, rule: false }, "THE HOUSE"),
    ce("div", { style: { display: "flex", alignItems: "baseline", gap: 12, marginBottom: 6 } },
      ce("span", { style: { fontFamily: SERIF, fontWeight: 700, fontSize: 60, lineHeight: 0.9, color: tempColor(P, t.outdoor, "now") } }, t.outdoor + "°"),
      ce("span", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink } }, "OUTSIDE NOW")),
    ce("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 22px", marginTop: 12 } },
      floors.map((f, i) =>
        ce("div", { key: i, style: { display: "flex", justifyContent: "space-between", alignItems: "baseline" } },
          ce("span", { className: "pix16", style: { letterSpacing: "0.1em", color: P.ink } }, f[0]),
          ce("span", { style: { fontFamily: SERIF, fontWeight: 600, fontSize: 24, color: P.ink } }, f[1] + "°")))),
    ce("div", { style: { display: "flex", alignItems: "center", gap: 18, flexWrap: "wrap", marginTop: 16 } },
      day.house.people.map((p, i) =>
        ce("div", { key: i, style: { display: "flex", alignItems: "center", gap: 7 } },
          ce(EDot, { size: 13, color: p.home ? acc(P, "green") : P.ink, filled: p.home }),
          ce("span", { className: "pix16", style: { letterSpacing: "0.06em", color: P.ink } }, `${p.name.toUpperCase()} ${p.home ? "HOME" : "OUT"}`))),
      day.house.advisory && ce("div", { style: { display: "flex", alignItems: "center", gap: 7 } },
        ce("div", { style: { width: 11, height: 11, background: acc(P, "yellow"), transform: "rotate(45deg)" } }),
        ce("span", { className: "pix16", style: { letterSpacing: "0.06em", color: P.ink } }, day.house.advisory.toUpperCase()))));
}

/* ── colophon ──────────────────────────────────────────────────── */
function Colophon({ day, P }) {
  const t = day.tomorrow.first;
  const gem = (c) => ce("div", { style: { width: 8, height: 8, background: acc(P, c), transform: "rotate(45deg)" } });
  return ce("div", null,
    ce(SpotRule, { P, mb: 8 }),
    ce("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } },
      ce("span", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink } },
        `TOMORROW · ${t.start} ${t.title.toUpperCase()}`),
      ce("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, gem("red"), gem("blue"), gem("green")),
      ce("span", { className: "pix16", style: { letterSpacing: "0.08em", color: P.ink } }, `↻ ${day.asOf.toUpperCase()}`)));
}

function min2hhmm(m) { return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`; }

/* ── frame ─────────────────────────────────────────────────────── */
function EditorialPortrait({ day, palette = "six" }) {
  const P = DA_E_PALETTE[palette] || DA_E_PALETTE.six;
  return ce("div", { style: {
      width: 1200, height: 1600, background: P.bg, color: P.ink, boxSizing: "border-box",
      padding: "30px 46px 26px", fontFamily: SERIF, position: "relative",
      display: "flex", flexDirection: "column", overflow: "hidden" } },
    ce(Masthead, { day, P }),
    ce(WeatherBand, { day, P }),
    ce("div", { style: { marginTop: 22 } }, ce(Lead, { day, P })),
    ce("div", { style: { marginTop: 24 } }, ce(Timeline, { day, P })),
    ce("div", { style: { flex: 1 } }),
    ce("div", { style: { marginTop: 16 } }, ce(BottomRails, { day, P })),
    ce("div", { style: { marginTop: 14 } }, ce(Colophon, { day, P })));
}

Object.assign(window, { EditorialPortrait, DA_E_PALETTE });
})();
