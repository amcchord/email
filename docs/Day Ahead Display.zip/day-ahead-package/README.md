# Day Ahead Display — Implementation Package

A hand-off package for an LLM/engineer to build a **glanceable "Day Ahead"
screen** for a **13.3″ E-Ink Spectra-6 panel (1200×1600, portrait)**, rendered
server-side inside the existing **`amcchord/email`** repo (the self-hosted mail +
calendar app) and pushed to the panel over the reTerminal protocol that repo
already implements.

The screen refreshes **once an hour** and shows the day ahead: a date masthead,
the next event, today's timeline, emails needing a reply, weather, and slow
house state — in a printed-broadsheet style with the 6-colour Spectra palette
used as information.

---

## Read in this order

1. **`IMPLEMENTATION-HANDOFF.md`** — the full brief. Architecture, the exact
   files to add/edit in `amcchord/email`, the `DayShape` data contract + where
   each field comes from, the colour/halftone system, the type scale and layout
   constants, the e-ink rendering rules, and a build checklist (§13). **This is
   the spec — start here.**
2. **`mockup/Day Ahead Display.html`** — open in a browser. The **pixel-level
   visual reference**: the chosen **Editorial** direction (shown in a *busy*
   morning and a *calm* evening state) plus the **Swiss** fallback. Use it to
   read exact sizes, colours, spacing, and the halftone treatments.
3. **`preview.png`** — a static render of the mockup if you can't run a browser.

Then implement against the real repo using the file map in the handoff (§3).

---

## What you are building (one paragraph)

A new `day_ahead` **content type** for the terminal renderer. It (1) assembles a
`DayShape` from the app's calendar events, needs-reply/awaiting/unread email
queues, todos, and the existing Home-Assistant weather+house data; (2) draws it
at **1200×1600** with **Pillow**, in a new `dayahead_editorial.py` design module
that mirrors the mockup; (3) encodes it with the repo's existing
`encode_spectra6(..., dither=False)` and serves it through the existing
`/terminal/{code}/` endpoints at an hourly cadence. You are **not** writing a new
BMP encoder or device protocol — both already exist and already support this
panel (variant `spectra6_1200x1600`). See handoff §3 for the precise plug-in
points and §13 for the checklist.

---

## File manifest

```
day-ahead-package/
├─ README.md                     ← you are here
├─ IMPLEMENTATION-HANDOFF.md     ← THE SPEC — read first
├─ preview.png                   ← static render of the mockup
├─ mockup/                       ← runnable visual reference (browser)
│  ├─ Day Ahead Display.html     ← open this
│  ├─ editorial.jsx              ← Direction A (SHIP THIS) — transcription target for Pillow
│  ├─ swiss.jsx                  ← Direction B (documented fallback, not shipped)
│  ├─ atoms.jsx                  ← shared WeatherGlyph / Diamond / Dot
│  ├─ data.js                    ← the DayShape contract + two sample fixtures
│  ├─ fonts.css                  ← TRMNL @font-face + the no-AA pixel class
│  └─ fonts/trmnl/*.woff2        ← TRMNL pixel font (browser, for the mockup)
└─ server-fonts/trmnl/*.ttf      ← TRMNL pixel font (TTF, for the Pillow renderer)
```

### About the two font folders
- `mockup/fonts/trmnl/*.woff2` is only so the HTML mockup renders in a browser.
- **`server-fonts/trmnl/*.ttf`** is what you install on the server — copy it to
  `backend/services/eink/static/fonts/trmnl/` and load it with the `pix_trmnl()`
  helper in handoff §7. TRMNL has three native bitmap sizes (12 / 16 / 21);
  **never request a non-native size** (scaling a bitmap face corrupts glyphs).

---

## Key facts (so nothing gets re-derived wrong)

- **Panel:** E1004, 13.3″ Spectra-6, native **1200×1600 portrait**, 6 colours
  (black/white/red/green/blue/yellow), no greys, no anti-aliasing.
- **Variant / format:** `?variant=spectra6_1200x1600` → `bmp4-spectra6-1200x1600`,
  960,118-byte BMP. Already in `backend/services/terminal/variants.py`.
- **Cadence:** hourly. Set the device `refresh_interval_sec = 3600`; the schedule
  endpoint already honours it. Bucket "now" to the hour so the image is
  byte-stable within the hour (stable ETag → device skips the fetch).
- **Type:** everything ≤ 24 px is a **TRMNL pixel font** at its native size;
  larger display type is **Source Serif 4**.
- **Colour is information:** highs = red, lows = blue, meetings = blue, personal
  = green, needs-you/now/overdue = red, advisory/sun = yellow (marks only).
- **The dithering trick:** extra hues (the time-of-day **sky** behind the date,
  the faint fact-strip wash) are **drawn dot grids** of two native inks — an
  ordered dither painted directly, **never** Floyd–Steinberg, and **never** under
  text. The encoder runs with `dither=False`. See handoff §6.2 + §11.4.
- **Weather icons are black & white.** Weather's colour comes from the
  temperatures, not the glyph.

---

## Definition of done

Implements handoff §13's checklist, and:
- `GET /terminal/{code}/schedule.json?variant=spectra6_1200x1600` advertises
  `image.format = "bmp4-spectra6-1200x1600"` and `next_checkin_sec ≈ 3600`.
- `GET /terminal/{code}/image.bmp?variant=spectra6_1200x1600` returns a
  960,118-byte BMP whose first 6 palette entries are K/W/G/B/R/Y.
- Two check-ins within the same hour return an identical ETag.
- Rendering the design against a busy and an empty `DayShape` produces a frame
  with **≤ 6 unique colours** (`convert out.bmp -unique-colors txt:`), no greys,
  and crisp (un-dithered) text.
- The output visually matches `mockup/Day Ahead Display.html` (Editorial).
